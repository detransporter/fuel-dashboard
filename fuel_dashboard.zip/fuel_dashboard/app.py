"""
Fuel Market Dashboard — Live data från EIA/FRED
Brent Crude · WTI · Diesel · Jet Fuel
"""

import streamlit as st
import requests
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import numpy as np

# ─── Page config ────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Fuel Market Dashboard",
    page_icon="🛢️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── Custom CSS ─────────────────────────────────────────────────────────────
st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Syne:wght@400;700;800&display=swap');

  html, body, [class*="css"] {
    font-family: 'Syne', sans-serif;
    background-color: #0a0e1a;
    color: #e8eaf0;
  }

  .main { background-color: #0a0e1a; }

  .metric-card {
    background: linear-gradient(135deg, #111827 0%, #1a2235 100%);
    border: 1px solid #2a3550;
    border-radius: 12px;
    padding: 20px 24px;
    margin-bottom: 12px;
    position: relative;
    overflow: hidden;
  }
  .metric-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    background: var(--accent);
  }
  .metric-label {
    font-family: 'DM Mono', monospace;
    font-size: 11px;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: #6b7fa3;
    margin-bottom: 6px;
  }
  .metric-value {
    font-size: 32px;
    font-weight: 800;
    color: #f0f4ff;
    line-height: 1.1;
    font-family: 'DM Mono', monospace;
  }
  .metric-delta-up   { color: #ef4444; font-size: 14px; font-family: 'DM Mono', monospace; }
  .metric-delta-down { color: #22c55e; font-size: 14px; font-family: 'DM Mono', monospace; }
  .metric-unit { font-size: 14px; color: #6b7fa3; margin-left: 4px; }

  .section-header {
    font-family: 'Syne', sans-serif;
    font-weight: 800;
    font-size: 13px;
    letter-spacing: 3px;
    text-transform: uppercase;
    color: #4a6fa5;
    border-bottom: 1px solid #1e2d45;
    padding-bottom: 8px;
    margin: 28px 0 16px 0;
  }

  .alert-box {
    background: rgba(239,68,68,0.1);
    border: 1px solid rgba(239,68,68,0.3);
    border-left: 4px solid #ef4444;
    border-radius: 8px;
    padding: 12px 16px;
    margin-bottom: 16px;
    font-size: 13px;
    color: #fca5a5;
  }

  .stSelectbox label, .stSlider label, .stDateInput label {
    color: #6b7fa3 !important;
    font-family: 'DM Mono', monospace !important;
    font-size: 12px !important;
    letter-spacing: 1px !important;
    text-transform: uppercase !important;
  }

  div[data-testid="metric-container"] { display: none; }

  footer { visibility: hidden; }
  #MainMenu { visibility: hidden; }

  .stApp > header { background: transparent; }

  h1 { font-family: 'Syne', sans-serif; font-weight: 800; color: #f0f4ff; }
  h2, h3 { font-family: 'Syne', sans-serif; color: #c8d0e7; }
</style>
""", unsafe_allow_html=True)


# ─── FRED API helpers ────────────────────────────────────────────────────────
FRED_BASE = "https://api.stlouisfed.org/fred/series/observations"

# Series IDs from FRED (no API key needed for these public series via FRED)
SERIES = {
    "Brent Crude ($/fat)": {
        "id": "DCOILBRENTEU",
        "unit": "$/fat",
        "color": "#f59e0b",
        "accent": "#f59e0b"
    },
    "WTI Crude ($/fat)": {
        "id": "DCOILWTICO",
        "unit": "$/fat",
        "color": "#3b82f6",
        "accent": "#3b82f6"
    },
    "Diesel US ($/gallon)": {
        "id": "GASDESW",
        "unit": "$/gal",
        "color": "#8b5cf6",
        "accent": "#8b5cf6"
    },
    "Jet Fuel Gulf Coast ($/gallon)": {
        "id": "WJFUELUSGULF",
        "unit": "$/gal",
        "color": "#06b6d4",
        "accent": "#06b6d4"
    },
}

@st.cache_data(ttl=3600)
def fetch_fred_series(series_id: str, start_date: str, api_key: str = ""):
    """Fetch data from FRED. Uses public endpoint if no API key provided."""
    params = {
        "series_id": series_id,
        "observation_start": start_date,
        "file_type": "json",
        "sort_order": "asc",
    }
    if api_key:
        params["api_key"] = api_key
    else:
        params["api_key"] = "abcdefghijklmnopqrstuvwxyz123456"  # placeholder — see note

    try:
        r = requests.get(FRED_BASE, params=params, timeout=10)
        data = r.json()
        if "observations" not in data:
            return None
        df = pd.DataFrame(data["observations"])
        df["date"] = pd.to_datetime(df["date"])
        df["value"] = pd.to_numeric(df["value"], errors="coerce")
        df = df.dropna(subset=["value"])
        return df[["date", "value"]].set_index("date")
    except Exception as e:
        return None


def pct_change(series: pd.Series, days: int) -> float | None:
    if len(series) < 2:
        return None
    recent = series.iloc[-1]
    past_idx = max(0, len(series) - days)
    past = series.iloc[past_idx]
    if past == 0:
        return None
    return ((recent - past) / past) * 100


def render_metric_card(label: str, value: float | None, unit: str,
                        delta_1w: float | None, delta_1m: float | None,
                        accent: str):
    if value is None:
        val_str = "N/A"
    else:
        val_str = f"{value:,.2f}"

    def delta_html(d, label):
        if d is None:
            return f'<span style="color:#6b7fa3">{label}: –</span>'
        cls = "metric-delta-up" if d > 0 else "metric-delta-down"
        arrow = "▲" if d > 0 else "▼"
        return f'<span class="{cls}">{arrow} {abs(d):.1f}% {label}</span>'

    st.markdown(f"""
    <div class="metric-card" style="--accent:{accent}">
      <div class="metric-label">{label}</div>
      <div class="metric-value">{val_str}<span class="metric-unit">{unit}</span></div>
      <div style="margin-top:8px; display:flex; gap:16px; flex-wrap:wrap;">
        {delta_html(delta_1w, "1v")}
        {delta_html(delta_1m, "1m")}
      </div>
    </div>
    """, unsafe_allow_html=True)


# ─── Sidebar ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🛢️ Fuel Dashboard")
    st.markdown("---")

    api_key = st.text_input(
        "FRED API-nyckel (valfri)",
        type="password",
        help="Gratis på fred.stlouisfed.org/docs/api/api_key.html — krävs för live-data"
    )

    period = st.selectbox(
        "Tidsperiod",
        ["3 månader", "6 månader", "1 år", "2 år", "5 år"],
        index=2
    )

    period_map = {
        "3 månader": 90,
        "6 månader": 180,
        "1 år": 365,
        "2 år": 730,
        "5 år": 1825
    }
    days_back = period_map[period]
    start_date = (datetime.today() - timedelta(days=days_back)).strftime("%Y-%m-%d")

    st.markdown("---")
    selected = st.multiselect(
        "Visa instrument",
        list(SERIES.keys()),
        default=list(SERIES.keys())
    )

    st.markdown("---")
    show_corr = st.checkbox("Visa korrelationsmatris", value=True)
    show_vol = st.checkbox("Visa volatilitet (30d rullande)", value=True)

    st.markdown("---")
    st.markdown("""
    <div style='font-family:DM Mono,monospace;font-size:11px;color:#4a6fa5;line-height:1.8'>
    Datakälla: FRED (St. Louis Fed)<br>
    EIA · IATA · IEA<br><br>
    Uppdateras: varje timme<br>
    Senast: """ + datetime.now().strftime("%Y-%m-%d %H:%M") + """
    </div>
    """, unsafe_allow_html=True)


# ─── Main content ─────────────────────────────────────────────────────────────
st.markdown("""
<h1 style='margin-bottom:4px'>Fuel Market Dashboard</h1>
<div style='font-family:DM Mono,monospace;font-size:12px;color:#4a6fa5;margin-bottom:24px'>
  BRENT CRUDE · WTI · DIESEL · JET FUEL — LIVE DATA VIA FRED/EIA
</div>
""", unsafe_allow_html=True)

# Alert box — current market situation
st.markdown("""
<div class="alert-box">
  ⚠️ <strong>MARKNADSLÄGE MARS 2026:</strong> Hormuzsundet i praktiken stängt sedan 28 feb.
  Brent +50% YTD · Diesel +44% sedan jan · Jet fuel +11% senaste veckan.
  IEA har frigjort 400 miljoner fat från strategiska reserver.
</div>
""", unsafe_allow_html=True)

# ─── Fetch data ────────────────────────────────────────────────────────────
data_store: dict[str, pd.DataFrame] = {}

with st.spinner("Hämtar live-data från FRED..."):
    for name in selected:
        sid = SERIES[name]["id"]
        df = fetch_fred_series(sid, start_date, api_key)
        if df is not None and not df.empty:
            data_store[name] = df

if not data_store:
    st.error("""
    **Kunde inte hämta live-data från FRED.**

    För att aktivera live-data:
    1. Gå till [fred.stlouisfed.org/docs/api/api_key.html](https://fred.stlouisfed.org/docs/api/api_key.html)
    2. Skapa ett gratis konto och generera en API-nyckel
    3. Klistra in nyckeln i sidofältet

    I mellantid visas simulerad data baserad på verkliga marknadsnivåer.
    """)

    # ── Fallback: simulerad data baserad på verkliga nivåer ─────────────────
    np.random.seed(42)
    dates = pd.date_range(start=start_date, end=datetime.today(), freq="B")
    n = len(dates)

    fallback_params = {
        "Brent Crude ($/fat)":          {"start": 62, "end": 94,  "vol": 0.018},
        "WTI Crude ($/fat)":            {"start": 59, "end": 91,  "vol": 0.019},
        "Diesel US ($/gallon)":         {"start": 3.53, "end": 5.07, "vol": 0.012},
        "Jet Fuel Gulf Coast ($/gallon)":{"start": 2.20, "end": 3.80, "vol": 0.015},
    }

    for name in selected:
        if name in fallback_params:
            p = fallback_params[name]
            trend = np.linspace(p["start"], p["end"], n)
            noise = np.random.normal(0, p["vol"], n)
            cum_noise = np.cumsum(noise) * p["start"]
            vals = trend + cum_noise * 0.3
            # Spike around Hormuz crisis (day ~n-15 to n)
            spike_start = max(0, n - 18)
            vals[spike_start:] *= np.linspace(1.0, 1.12, n - spike_start)
            df = pd.DataFrame({"value": vals}, index=dates)
            data_store[name] = df


# ─── KPI metrics ─────────────────────────────────────────────────────────────
st.markdown('<div class="section-header">Senaste priser</div>', unsafe_allow_html=True)

cols = st.columns(len(selected) if selected else 1)
for i, name in enumerate(selected):
    if name not in data_store:
        continue
    df = data_store[name]
    meta = SERIES[name]
    latest = df["value"].iloc[-1] if not df.empty else None
    d1w = pct_change(df["value"], 7)
    d1m = pct_change(df["value"], 30)
    with cols[i]:
        render_metric_card(name, latest, meta["unit"], d1w, d1m, meta["accent"])


# ─── Main chart ───────────────────────────────────────────────────────────────
st.markdown('<div class="section-header">Prisutveckling</div>', unsafe_allow_html=True)

if data_store:
    # Normalize toggle
    normalize = st.toggle("Normalisera till index (start = 100)", value=False)

    fig = go.Figure()

    for name in selected:
        if name not in data_store:
            continue
        df = data_store[name]
        meta = SERIES[name]
        vals = df["value"]
        if normalize:
            vals = (vals / vals.iloc[0]) * 100
            hover_suffix = " (index)"
        else:
            hover_suffix = f" {meta['unit']}"

        fig.add_trace(go.Scatter(
            x=df.index,
            y=vals,
            name=name,
            line=dict(color=meta["color"], width=2.5),
            hovertemplate=f"<b>{name}</b><br>%{{x|%Y-%m-%d}}<br>%{{y:.2f}}{hover_suffix}<extra></extra>",
            fill="tozeroy" if len(selected) == 1 else None,
            fillcolor=meta["color"].replace(")", ",0.05)").replace("rgb", "rgba") if len(selected) == 1 else None,
        ))

    # Add Hormuz crisis annotation
    crisis_date = "2026-02-28"
    if pd.to_datetime(crisis_date) >= pd.to_datetime(start_date):
        fig.add_vline(
            x=crisis_date,
            line_dash="dot",
            line_color="#ef4444",
            line_width=1.5,
            annotation_text="Hormuz-krisen",
            annotation_position="top left",
            annotation_font_color="#ef4444",
            annotation_font_size=11,
        )

    fig.update_layout(
        paper_bgcolor="#0a0e1a",
        plot_bgcolor="#0d1424",
        font=dict(family="DM Mono, monospace", color="#8896b3", size=11),
        legend=dict(
            orientation="h",
            yanchor="bottom", y=1.02,
            xanchor="left", x=0,
            bgcolor="rgba(0,0,0,0)",
            font=dict(size=11),
        ),
        xaxis=dict(
            gridcolor="#1a2540",
            linecolor="#1a2540",
            showgrid=True,
        ),
        yaxis=dict(
            gridcolor="#1a2540",
            linecolor="#1a2540",
            showgrid=True,
            title="Pris (normaliserat)" if normalize else "Pris",
        ),
        hovermode="x unified",
        height=420,
        margin=dict(l=60, r=20, t=40, b=40),
    )

    st.plotly_chart(fig, use_container_width=True)


# ─── Volatility chart ─────────────────────────────────────────────────────────
if show_vol and data_store:
    st.markdown('<div class="section-header">30-dagars rullande volatilitet (std dev %)</div>', unsafe_allow_html=True)

    fig_vol = go.Figure()
    for name in selected:
        if name not in data_store:
            continue
        df = data_store[name]
        meta = SERIES[name]
        pct = df["value"].pct_change() * 100
        vol = pct.rolling(30).std()
        fig_vol.add_trace(go.Scatter(
            x=vol.index,
            y=vol,
            name=name,
            line=dict(color=meta["color"], width=2),
            hovertemplate=f"<b>{name}</b><br>%{{x|%Y-%m-%d}}<br>Volatilitet: %{{y:.2f}}%<extra></extra>",
        ))

    fig_vol.update_layout(
        paper_bgcolor="#0a0e1a",
        plot_bgcolor="#0d1424",
        font=dict(family="DM Mono, monospace", color="#8896b3", size=11),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0, bgcolor="rgba(0,0,0,0)"),
        xaxis=dict(gridcolor="#1a2540", linecolor="#1a2540"),
        yaxis=dict(gridcolor="#1a2540", linecolor="#1a2540", title="Std dev (%)"),
        height=280,
        margin=dict(l=60, r=20, t=40, b=40),
    )
    st.plotly_chart(fig_vol, use_container_width=True)


# ─── Correlation matrix ───────────────────────────────────────────────────────
if show_corr and len(data_store) >= 2:
    st.markdown('<div class="section-header">Korrelationsmatris (dagliga prisförändringar)</div>', unsafe_allow_html=True)

    # Build combined dataframe
    combined = pd.DataFrame()
    for name in selected:
        if name in data_store:
            combined[name] = data_store[name]["value"]

    combined = combined.dropna()
    corr = combined.pct_change().corr()

    short_names = {n: n.split(" (")[0] for n in corr.columns}
    corr.columns = [short_names[c] for c in corr.columns]
    corr.index = [short_names[c] for c in corr.index]

    fig_corr = go.Figure(go.Heatmap(
        z=corr.values,
        x=corr.columns.tolist(),
        y=corr.index.tolist(),
        colorscale=[
            [0.0, "#1e3a5f"],
            [0.5, "#1a2540"],
            [1.0, "#f59e0b"],
        ],
        zmin=-1, zmax=1,
        text=[[f"{v:.2f}" for v in row] for row in corr.values],
        texttemplate="%{text}",
        textfont=dict(family="DM Mono, monospace", size=13, color="#e8eaf0"),
        showscale=True,
    ))

    fig_corr.update_layout(
        paper_bgcolor="#0a0e1a",
        plot_bgcolor="#0d1424",
        font=dict(family="DM Mono, monospace", color="#8896b3", size=12),
        height=320,
        margin=dict(l=20, r=20, t=20, b=20),
    )
    st.plotly_chart(fig_corr, use_container_width=True)


# ─── Data table ───────────────────────────────────────────────────────────────
with st.expander("📊 Rådata (senaste 30 observationer)"):
    combined_raw = pd.DataFrame()
    for name in selected:
        if name in data_store:
            combined_raw[name] = data_store[name]["value"]
    if not combined_raw.empty:
        st.dataframe(
            combined_raw.tail(30).style
                .format("{:.2f}")
                .background_gradient(cmap="YlOrRd", axis=0),
            use_container_width=True
        )


# ─── Footer ───────────────────────────────────────────────────────────────────
st.markdown("""
<hr style='border-color:#1a2540;margin-top:40px'>
<div style='font-family:DM Mono,monospace;font-size:11px;color:#2d3f5f;text-align:center;padding:16px'>
  Datakälla: FRED (Federal Reserve Bank of St. Louis) · EIA · IATA · IEA<br>
  Dashboard byggd av SCM International · """ + datetime.now().strftime("%Y") + """
</div>
""", unsafe_allow_html=True)
